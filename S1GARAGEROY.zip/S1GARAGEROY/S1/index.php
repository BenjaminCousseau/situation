<!DOCTYPE html>
<html lang="fr">

<?php include 'include/head.php'; ?>

<body>
    <?php include 'include/header.php'; ?>

    <?php include 'include/banner.php'; ?>

    <?php include 'include/services.php'; ?>
    
    <?php include 'include/contact.php'; ?>
    
    <?php include 'include/footer.php'; ?>
    
</body>
</html>