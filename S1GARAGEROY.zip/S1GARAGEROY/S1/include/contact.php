<section id="contact">
        <div class="container">
        <?php        
            include 'include/connection.php';
            $requete = "SELECT * FROM titlecontact";
            $resultat = $mysqli->query($requete);
            while ($ligne = $resultat->fetch_assoc()) {
                    echo '<h2>';
                    echo $ligne['titre'] . '</h2>';
            }
                        $mysqli->close();
        ?>
        
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM contact";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo '<p>';
                        echo $ligne['texte'] . '</p>';
                }
                        $mysqli->close();
        ?>
        </div>
</section>