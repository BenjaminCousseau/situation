<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM title";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo '<title>';
                        echo $ligne['titre'] . '</title>';
                }
                $mysqli->close();
        ?>
    <link rel="stylesheet" href="style.css">
</head>

