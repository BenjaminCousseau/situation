<?php 
    $mysqli = new mysqli("localhost", "root", "", "garageroy");
    $mysqli->set_charset("utf8");
?>