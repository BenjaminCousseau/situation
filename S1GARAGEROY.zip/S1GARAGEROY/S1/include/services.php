<section id="services">
        <div class="container">
        <?php        
            include 'include/connection.php';
            $requete = "SELECT * FROM titleservice";
            $resultat = $mysqli->query($requete);
            while ($ligne = $resultat->fetch_assoc()) {
                    echo '<h2>';
                    echo $ligne['titre'] . '</h2>';
            }
                        $mysqli->close();
        ?>
        <ul>
            <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM services";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo '<li>';
                        echo $ligne['texte'] . '</li>';
                }
                        $mysqli->close();
            ?>   
        </ul>
        </div>
    </section>