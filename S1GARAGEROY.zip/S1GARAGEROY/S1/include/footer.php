<footer>
        <div class="container">
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM `footer` WHERE id = 1";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo '<p>';
                        echo $ligne['texte'];
                }
                $mysqli->close();
        ?>
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM title";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo $ligne['titre'];
                }
                $mysqli->close();
        ?>
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM `footer` WHERE id = 2";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo $ligne['texte'];
                        echo '</p>';
                }
                $mysqli->close();
        ?>
        </div>
</footer>