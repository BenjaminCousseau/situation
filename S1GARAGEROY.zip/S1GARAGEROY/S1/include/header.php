<header>
        <div class="container">
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM title";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo '<h1>';
                        echo $ligne['titre'] . '</h1>';
                }
                $mysqli->close();
        ?>
            <nav>
                <ul>
                    <?php        
                        include 'include/connection.php';
                        $requete = "SELECT * FROM titleservice";
                        $resultat = $mysqli->query($requete);
                        while ($ligne = $resultat->fetch_assoc()) {
                                echo '<li><a href="#services">';
                                echo $ligne['titre'] . '</a></li>';
                        }
                        $mysqli->close();
                    ?>
                    <?php        
                        include 'include/connection.php';
                        $requete = "SELECT * FROM titlecontact";
                        $resultat = $mysqli->query($requete);
                        while ($ligne = $resultat->fetch_assoc()) {
                                echo '<li><a href="#contact">';
                                echo $ligne['titre'] . '</a></li>';
                        }
                        $mysqli->close();
                    ?>
                </ul>
            </nav>
        </div>
</header>