<section id="banner">
        <div class="container">
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM `text` WHERE id = 1";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo '<h2>';
                        echo $ligne['texte'];
                }
                $mysqli->close();
        ?>
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM title";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo $ligne['titre'] . '</h2>';
                }
                $mysqli->close();
        ?>
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM `text` WHERE id = 2";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo '<p>';
                        echo $ligne['texte'];
                        echo '</p>';
                }
                $mysqli->close();
        ?>
        </div>
</section>