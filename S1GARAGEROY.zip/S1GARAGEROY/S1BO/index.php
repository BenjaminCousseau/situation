<?php
    include 'include/connection.php';

    // Fonction pour récupérer tous les services
    function getAllServices($mysqli) {
        $services = array();
        $query = "SELECT * FROM services";
        $result = $mysqli->query($query);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $services[] = $row;
            }
        }
        return $services;
    }

    // Ajout d'un service
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_service'])) {
        $texte = $_POST['texte'];
        $query = "INSERT INTO services (texte) VALUES ('$texte')";
        $mysqli->query($query);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    // Modification d'un service
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_service'])) {
        $id = $_POST['id'];
        $texte = $_POST['texte'];
        $query = "UPDATE services SET texte = '$texte' WHERE id = $id";
        $mysqli->query($query);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    // Suppression d'un service
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_service'])) {
        $id = $_POST['id'];
        $query = "DELETE FROM services WHERE id = $id";
        $mysqli->query($query);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    // Affichage des services
    $services = getAllServices($mysqli);
?>














<?php
    include 'include/connection.php';

    // Fonction pour récupérer tous les contacts
    function getAllContacts($mysqli) {
        $contacts = array();
        $query = "SELECT * FROM contact";
        $result = $mysqli->query($query);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $contacts[] = $row;
            }
        }
        return $contacts;
    }

    // Ajout d'un contact
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_contact'])) {
        $texte = $_POST['texte'];
        $query = "INSERT INTO contact (texte) VALUES ('$texte')";
        $mysqli->query($query);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    // Modification d'un contact
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_contact'])) {
        $id = $_POST['id'];
        $texte = $_POST['texte'];
        $query = "UPDATE contact SET texte = '$texte' WHERE id = $id";
        $mysqli->query($query);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    // Suppression d'un contact
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_contact'])) {
        $id = $_POST['id'];
        $query = "DELETE FROM contact WHERE id = $id";
        $mysqli->query($query);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    // Affichage des contacts
    $contacts = getAllContacts($mysqli);
?>



















<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php        
                include 'include/connection.php';
                $requete = "SELECT * FROM title";
                $resultat = $mysqli->query($requete);
                while ($ligne = $resultat->fetch_assoc()) {
                        echo '<title>Back-Office ';
                        echo $ligne['titre'] . '</title>';
                }
                $mysqli->close();
        ?>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php        
            include 'include/connection.php';
            $requete = "SELECT * FROM title";
            $resultat = $mysqli->query($requete);
            while ($ligne = $resultat->fetch_assoc()) {
                    echo '<h1><center>Back-Office ';
                    echo $ligne['titre'] . '<center></h1>';
            }
            $mysqli->close();
    ?>



<?php        
          include 'include/connection.php';
          $requete = "SELECT * FROM title";
          $resultat = $mysqli->query($requete);
          while ($ligne = $resultat->fetch_assoc()) { ?>


                






        <div class="card card-secondary">
<div class="card-header">
    <h3 class="card-title">Nom du Garage :</h3>
</div>
<div class="card-body">
    <div class="row">
        <div class="col-3">
            <input type="textarea" class="form-control2" id="titre" value="<?php echo $ligne['titre']; ?>">
        </div>

        <div class="col-6">
            <p></p>
        </div>
        </div>

</div>

<?php
}
$mysqli->close();
?>



<button type="button" class="btn btn-block btn-success" id="modifierBtn">Modifier</button>
<script>
document.getElementById('modifierBtn').addEventListener('click', function() {
    var titre = document.getElementById('titre').value;

    // Utilisez XMLHttpRequest ou fetch pour envoyer les données au script PHP côté serveur
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'modifier_titre.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Traitez la réponse du serveur si nécessaire
            alert(xhr.responseText);
        }
    };
    xhr.send('titre=' + encodeURIComponent(titre));
});
</script>


</div>






<?php        
          include 'include/connection.php';
          $requete = "SELECT * FROM titlecontact";
          $resultat = $mysqli->query($requete);
          while ($ligne = $resultat->fetch_assoc()) { ?>


                






        <div class="card card-secondary">
<div class="card-header">
    <h3 class="card-title">Nom des rubriques :</h3>
</div>
<div class="card-body">
    <div class="row">
        <div class="col-3">
            <input type="textarea" class="form-control2" id="titrecontact" value="<?php echo $ligne['titre']; ?>">
        </div>

        <div class="col-6">
            <p></p>
        </div>
        </div>

</div>

<?php
}
$mysqli->close();
?>



<button type="button" class="btn btn-block btn-success" id="modifierBtncontact">Modifier</button>
<script>
document.getElementById('modifierBtncontact').addEventListener('click', function() {
    var titrecontact = document.getElementById('titrecontact').value;

    // Utilisez XMLHttpRequest ou fetch pour envoyer les données au script PHP côté serveur
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'modifier_titrecontact.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Traitez la réponse du serveur si nécessaire
            alert(xhr.responseText);
        }
    };
    xhr.send('titrecontact=' + encodeURIComponent(titrecontact));
});
</script>


</div>





<?php        
          include 'include/connection.php';
          $requete = "SELECT * FROM titleservice";
          $resultat = $mysqli->query($requete);
          while ($ligne = $resultat->fetch_assoc()) { ?>


                






        <div class="card card-secondary">
<div class="card-header">
          </br>
</div>
<div class="card-body">
    <div class="row">
        <div class="col-3">
            <input type="textarea" class="form-control2" id="titreservice" value="<?php echo $ligne['titre']; ?>">
        </div>

        <div class="col-6">
            <p></p>
        </div>
        </div>

</div>

<?php
}
$mysqli->close();
?>



<button type="button" class="btn btn-block btn-success" id="modifierBtnservice">Modifier</button>
<script>
document.getElementById('modifierBtnservice').addEventListener('click', function() {
    var titreservice = document.getElementById('titreservice').value;

    // Utilisez XMLHttpRequest ou fetch pour envoyer les données au script PHP côté serveur
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'modifier_titreservice.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Traitez la réponse du serveur si nécessaire
            alert(xhr.responseText);
        }
    };
    xhr.send('titreservice=' + encodeURIComponent(titreservice));
});
</script>


</div>










<?php        
          include 'include/connection.php';
          $requete = "SELECT * FROM `text` WHERE id = 1";
          $resultat = $mysqli->query($requete);
          while ($ligne = $resultat->fetch_assoc()) { ?>


                






        <div class="card card-secondary">
<div class="card-header">
    <h3 class="card-title">Texte Accueil 1 :</h3>
</div>
<div class="card-body">
    <div class="row">
        <div class="col-3">
            <input type="textarea" class="form-control2" id="txt1" value="<?php echo $ligne['texte']; ?>">
        </div>
        <p>(Le nom du garage serra inscrit automatiquement après le texte)</p>
        <div class="col-6">
            <p></p>
        </div>
        </div>

</div>

<?php
}
$mysqli->close();
?>




<button type="button" class="btn btn-block btn-success" id="modifierBtntxt1">Modifier</button>
<script>
document.getElementById('modifierBtntxt1').addEventListener('click', function() {
    var txt1 = document.getElementById('txt1').value;

    // Utilisez XMLHttpRequest ou fetch pour envoyer les données au script PHP côté serveur
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'modifier_txt1.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Traitez la réponse du serveur si nécessaire
            alert(xhr.responseText);
        }
    };
    xhr.send('txt1=' + encodeURIComponent(txt1));
});
</script>


</div>








<?php        
          include 'include/connection.php';
          $requete = "SELECT * FROM `text` WHERE id = 2";
          $resultat = $mysqli->query($requete);
          while ($ligne = $resultat->fetch_assoc()) { ?>


                






        <div class="card card-secondary">
<div class="card-header">
    <h3 class="card-title">Texte Accueil 2 :</h3>
</div>
<div class="card-body">
    <div class="row">
        <div class="col-3">
            <input type="textarea" class="form-control2" id="txt2" value="<?php echo $ligne['texte']; ?>">
        </div>

        <div class="col-6">
            <p></p>
        </div>
        </div>

</div>

<?php
}
$mysqli->close();
?>



<button type="button" class="btn btn-block btn-success" id="modifierBtntxt2">Modifier</button>
<script>
document.getElementById('modifierBtntxt2').addEventListener('click', function() {
    var txt2 = document.getElementById('txt2').value;

    // Utilisez XMLHttpRequest ou fetch pour envoyer les données au script PHP côté serveur
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'modifier_txt2.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Traitez la réponse du serveur si nécessaire
            alert(xhr.responseText);
        }
    };
    xhr.send('txt2=' + encodeURIComponent(txt2));
});
</script>


</div>




























<h1><u>Services</u></h1>

<h2>Ajouter un service</h2>
<form method="post">
    <input type="text" name="texte" placeholder="Nom du service" required>
    <button type="submit" name="add_service">Ajouter</button>
</form>

<h2>Modifier ou supprimer un service</h2>
<ul>
    <?php foreach ($services as $service): ?>
        <li>
            <form method="post">
                <input type="hidden" name="id" value="<?php echo $service['id']; ?>">
                <input type="text" name="texte" value="<?php echo $service['texte']; ?>" required>
                <button type="submit" name="update_service">Modifier</button>
                <button type="submit" name="delete_service">Supprimer</button>
            </form>
        </li>
    <?php endforeach; ?>
</ul>


<h1><u>Contact</u></h1>

    <h2>Ajouter un contact</h2>
    <form method="post">
        <input type="text" name="texte" placeholder="Nom du contact" required>
        <button type="submit" name="add_contact">Ajouter</button>
    </form>

    <h2>Modifier ou supprimer un contact</h2>
    <ul>
        <?php foreach ($contacts as $contact): ?>
            <li>
                <form method="post">
                    <input type="hidden" name="id" value="<?php echo $contact['id']; ?>">
                    <input type="text" name="texte" value="<?php echo $contact['texte']; ?>" required>
                    <button type="submit" name="update_contact">Modifier</button>
                    <button type="submit" name="delete_contact">Supprimer</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ul>







    <?php        
          include 'include/connection.php';
          $requete = "SELECT * FROM `footer` WHERE id = 1";
          $resultat = $mysqli->query($requete);
          while ($ligne = $resultat->fetch_assoc()) { ?>


                






        <div class="card card-secondary">
<div class="card-header">
    <h3 class="card-title">Footer 1 :</h3>
</div>
<div class="card-body">
    <div class="row">
        <div class="col-3">
            <input type="textarea" class="form-control2" id="ft1" value="<?php echo $ligne['texte']; ?>">
        </div>

        <div class="col-6">
            <p></p>
        </div>
        </div>

</div>

<?php
}
$mysqli->close();
?>



<button type="button" class="btn btn-block btn-success" id="modifierBtnft1">Modifier</button>
<script>
document.getElementById('modifierBtnft1').addEventListener('click', function() {
    var ft1 = document.getElementById('ft1').value;

    // Utilisez XMLHttpRequest ou fetch pour envoyer les données au script PHP côté serveur
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'modifier_ft1.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Traitez la réponse du serveur si nécessaire
            alert(xhr.responseText);
        }
    };
    xhr.send('ft1=' + encodeURIComponent(ft1));
});
</script>


</div>



<?php        
          include 'include/connection.php';
          $requete = "SELECT * FROM `footer` WHERE id = 2";
          $resultat = $mysqli->query($requete);
          while ($ligne = $resultat->fetch_assoc()) { ?>


                






        <div class="card card-secondary">
<div class="card-header">
    <h3 class="card-title">Footer 2 :</h3>
</div>
<div class="card-body">
    <div class="row">
        <div class="col-3">
            <input type="textarea" class="form-control2" id="ft2" value="<?php echo $ligne['texte']; ?>">
        </div>

        <div class="col-6">
            <p></p>
        </div>
        </div>

</div>

<?php
}
$mysqli->close();
?>



<button type="button" class="btn btn-block btn-success" id="modifierBtnft2">Modifier</button>
<script>
document.getElementById('modifierBtnft2').addEventListener('click', function() {
    var ft2 = document.getElementById('ft2').value;

    // Utilisez XMLHttpRequest ou fetch pour envoyer les données au script PHP côté serveur
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'modifier_ft2.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Traitez la réponse du serveur si nécessaire
            alert(xhr.responseText);
        }
    };
    xhr.send('ft2=' + encodeURIComponent(ft2));
});
</script>


</div>



</body>

</html>