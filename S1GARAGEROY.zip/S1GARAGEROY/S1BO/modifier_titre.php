<?php
include 'include/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titre = $_POST["titre"];

    // Préparez la requête de mise à jour
    $requete_mise_a_jour = $mysqli->prepare("UPDATE title SET titre = ?");
    
    // Binder les paramètres
    $requete_mise_a_jour->bind_param("s", $titre);

    // Exécutez la requête
    $requete_mise_a_jour->execute();

    // Fermez la requête
    $requete_mise_a_jour->close();

    echo "Le texte à été mis à jour avec succès.";
} else {
    echo "Erreur : méthode non autorisée.";
}
?>