<!DOCTYPE html>
<html lang="fr">
<?php include 'include/head.php'; ?>
<body>
<?php include 'include/header.php'; ?>

    <section id="accueil">
        <h2>Bienvenue à l'Hôtel ROY</h2>
        <p>Votre séjour de rêve commence ici.</p>
    </section>

    <?php include 'include/footer.php'; ?>
</body>
</html>