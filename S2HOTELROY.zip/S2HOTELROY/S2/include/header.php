<header>
        <h1>Hôtel ROY</h1>
        <nav>
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="chambres.php">Chambres</a></li>
                <li><a href="login.php">Connexion</a></li>
                <li><a href="compte.php">Mon Compte</a></li>
            </ul>
        </nav>
    </header>