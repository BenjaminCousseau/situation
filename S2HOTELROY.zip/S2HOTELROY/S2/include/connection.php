<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "hotel";
?>