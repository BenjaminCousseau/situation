<footer>
        <p>&copy; 2024 Hôtel ROY. Tous droits réservés.</p>
    </footer>